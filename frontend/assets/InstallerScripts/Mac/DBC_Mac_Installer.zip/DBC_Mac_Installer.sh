#!/bin/bash
echo "------------------------------------------
        Dota 2 Bot Configurator 
            Script Installer
------------------------------------------"
echo "Installing script into Dota 2..."
echo "Enter the zip file name: "
read fileName
unzip $fileName -d ~/Library/Application Support/Steam/steamapps/common/"dota 2 beta"/game/dota/scripts/vscripts/bots/
echo "Done"